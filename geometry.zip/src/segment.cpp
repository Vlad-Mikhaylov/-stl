#include "../segment.h"
#include "../line.h"

geometry::Segment &geometry::Segment::Move(const geometry::Vector &i) {
  first.Move(i);
  second.Move(i);
  return (*this);
}

bool geometry::Segment::ContainsPoint(const geometry::Point& value) const {
  return value.CrossesSegment(*this);
}

geometry::Segment* geometry::Segment::Clone() const {
  return new Segment(*this);
}

bool geometry::Segment::CrossesSegment(const geometry::Segment &other) const {
  Line line1(first, second);
  Line line2(other.first, other.second);
  if (line1.CrossesSegment(other) and line2.CrossesSegment(*this)) {
    bool con_1 = std::max(first.second, second.second) >= std::min(other.first.second, other.second.second);
    bool con_2 = std::max(first.first, second.first) >= std::min(other.first.first, other.second.first);
    return con_1 && con_2;
  }
  return false;
}

std::string geometry::Segment::ToString() const {
  return MakeString("Segment", first.ToString(), second.ToString());
}