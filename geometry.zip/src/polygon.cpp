#include "../polygon.h"
#include <vector>
#include "../segment.h"
#include "../ray.h"
#include "../line.h"

namespace geometry {

geometry::Polygon& geometry::Polygon::Move(const geometry::Vector& x) {
  for (auto &i : *this) {
    i.Move(x);
  }
  return *this;
}

bool Polygon::ContainsPoint(const Point& x) const {
  Point point(10002, x.second + 1);
  Ray ray(x, point);
  Line line(x, point);
  int64_t count = 0;
  for (size_t i = 0; i < (*this).size() - 1; ++i) {
    if (Segment((*this)[i], (*this)[i + 1]).ContainsPoint(ray.first)) {
      return true;
    }
    if (ray.CrossesSegment({(*this)[i], (*this)[i + 1]})) {
      ++count;
    }
  }
  if (ray.CrossesSegment({(*this)[0], (*this)[(*this).size() - 1]})) {
    if (Segment((*this)[0], (*this)[(*this).size() - 1]).ContainsPoint(ray.first)) {
      return true;
    }
    ++count;
  }
  return bool(count % 2);
}

bool Polygon::CrossesSegment(const Segment& x) const {
  for (size_t i = 0; i < (*this).size() - 1; ++i) {
    if (x.CrossesSegment({(*this)[i], (*this)[i + 1]})) {
      return true;
    }
    if (x.CrossesSegment({(*this)[(*this).size() - 1], (*this)[0]})) {
      return true;
    }
  }
  return false;
}

geometry::Polygon* geometry::Polygon::Clone() const {
  return new Polygon(*this);
}

std::string geometry::Polygon::ToString() const {
  std::string s = "Polygon(";
  for (auto &i : *this) {
    s += i.ToString() + ", ";
  }
  s.pop_back();
  s.pop_back();
  s.push_back(')');
  return s;
}

}  // namespace geometry
