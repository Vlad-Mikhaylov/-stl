#include "../ray.h"
#include "../line.h"
#include "../segment.h"

namespace geometry {

Ray &Ray::Move(const Vector& x) {
  first.Move(x);
  return *this;
}

bool Ray::ContainsPoint(const Point& x) const {
  Vector ret = x - first;
  return (!VectorProduct(ret, second) && DotProduct(ret, second) >= 0);
}

bool Ray::CrossesSegment(const Segment& x) const {
  if (x.ContainsPoint(first)) {
    return true;
  }
  Point tmp(first.first + second.first, first.second + second.second);
  Line line(first, tmp);

  if (line.CrossesSegment(x)) {
    Vector x_v = x.second - x.first;
    Vector v = first - x.first;

    return VectorProduct(x_v, v) * VectorProduct(x_v, second) <= 0;
  }

  return false;
}

Ray *Ray::Clone() const {
  return new geometry::Ray(*this);
}

std::string Ray::ToString() const {
  return MakeString("Ray", first.ToString(), second.ToString());
}
Ray &Ray::operator=(const Ray &other) {
  first = other.first;
  second = other.second;
  return *this;
}

}  // namespace geometry