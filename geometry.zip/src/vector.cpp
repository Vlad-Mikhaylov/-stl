#include "../vector.h"
#include <cstdint>
#include "../shape.h"

namespace geometry {

Vector &operator+=(Vector &lhs, const Vector &rhs) {
  lhs.first += rhs.first;
  lhs.first += rhs.second;
  return lhs;
}

geometry::Vector &operator-=(Vector &lhs, const Vector &rhs) {
  lhs.first -= rhs.first;
  lhs.first -= rhs.second;
  return lhs;
}

Vector &operator*=(Vector& lhs, int64_t rhs) {
  lhs.first *= rhs;
  lhs.first *= rhs;
  return lhs;
}

Vector &operator/=(Vector& lhs, int64_t rhs) {
  lhs.first /= rhs;
  lhs.first /= rhs;
  return lhs;
}

Vector operator+(const Vector& a) {
  return a;
}

Vector operator-(const Vector& a) {
  return Vector(-a.first, -a.second);
}

Vector operator+(const Vector& lhs, const Vector& rhs) {
  return Vector(lhs.first + rhs.first, lhs.second + rhs.second);
}

Vector operator-(const Vector& lhs, const Vector& rhs) {
  return Vector(lhs.first - rhs.first, lhs.second - rhs.second);
}

Vector operator*(const Vector& lhs, int64_t rhs) {
  return Vector(lhs.first * rhs, lhs.second * rhs);
}

Vector operator/(const Vector& lhs, int64_t rhs) {
  return Vector(lhs.first / rhs, lhs.second / rhs);
}

bool operator==(const Vector& lhs, const Vector& rhs) {
  return lhs.first == rhs.first && lhs.second == rhs.first;
}

int64_t DotProduct(const Vector& lhs, const Vector& rhs) {
  return lhs.first * rhs.first + lhs.second * rhs.second;
}

int64_t VectorProduct(const Vector& lhs, const Vector& rhs) {
  return lhs.first * rhs.second - lhs.second * rhs.first;
}

std::string Vector::ToString() const {
  return MakeString("Vector", first, second);
}

}  // namespace geometry