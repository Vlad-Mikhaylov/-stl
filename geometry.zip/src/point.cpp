#include "../point.h"

#include <string>
#include "../segment.h"

geometry::Point &geometry::Point::Move(const geometry::Vector& other) {
  this->first += other.first;
  this->second += other.second;
  return *this;
}

bool geometry::Point::ContainsPoint(const geometry::Point& other) const {
  return *this == other;
}

bool geometry::Point::CrossesSegment(const geometry::Segment& other) const {
  Vector temp_vec1(other.second - *this);
  Vector temp_vec2(*this - other.first);
  return !(VectorProduct(temp_vec1, temp_vec2)) && DotProduct(temp_vec1, temp_vec2) >= 0;
}

geometry::Point *geometry::Point::Clone() const {
  return new Point(*this);
}

std::string geometry::Point::ToString() const {
  return MakeString("Point", this->first, this->second);
}