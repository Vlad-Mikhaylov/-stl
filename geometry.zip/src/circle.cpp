#include "../circle.h"
#include "../segment.h"
#include "../line.h"

namespace geometry {

Circle& geometry::Circle::Move(const Vector& x) {
  first.Move(x);
  return *this;
}

bool Circle::ContainsPoint(const Point& other) const {
  int64_t x1 = (other.first - this->first.first) * (other.first - this->first.first);
  int64_t y1 = (other.second - this->first.second) * (other.second - this->first.second);
  int64_t radius = this->second * this->second;
  return x1 + y1 <= radius;
}

bool Circle::ContainsPoint1(const Point& x) const {
  int64_t radius = this->second * this->second;
  int64_t x1 = (x.first - this->first.first) * (x.first - this->first.first);
  int64_t y1 = (x.second - this->first.second) * (x.second - this->first.second);
  return x1 + y1 == radius;
}

Circle* geometry::Circle::Clone() const {
  return new Circle(*this);
}

std::string Circle::ToString() const {
  return MakeString("Circle", first.ToString(), second);
}

bool Circle::CrossesSegment(const Segment &other) const {
  if (ContainsPoint1(other.first) || ContainsPoint1(other.second)) {
    return true;
  }
  if (ContainsPoint(other.first) && !ContainsPoint(other.second)) {
    return true;
  }
  if (!ContainsPoint(other.first) && ContainsPoint(other.second)) {
    return true;
  }
  if (ContainsPoint(other.first) && ContainsPoint(other.second)) {
    return false;
  }
  Line other_line(other.first, other.second);
  int64_t val = other_line.Value(this->first);
  int64_t len = val * val;
  if (len > this->second * this->second * (other_line.A * other_line.A + other_line.B * other_line.B)) {
    return false;
  }
  const Vector normal = other_line.Normal();
  Point tmp(first.first + normal.first, first.second + normal.second);
  Line normal_line(first, tmp);
  return normal_line.CrossesSegment(other);
}

}  // namespace geometry