#include "../line.h"
#include "../segment.h"

geometry::Line::Line(const Point& a, const Point& b) {
  A = a.second - b.second;
  B = -a.first + b.first;
  C = (a.first - b.first) * b.second - (a.second - b.second) * b.first;
}

geometry::Line::Line(const int64_t& a, const int64_t& b, const int64_t& c) : A(a), B(b), C(c) {
}

geometry::Line &geometry::Line::Move(const geometry::Vector& vector) {
  C = C - A * vector.first - B * vector.second;
  return *this;
}

bool geometry::Line::ContainsPoint(const geometry::Point& point) const {
  return A * point.first + B * point.second + C == 0;
}

bool geometry::Line::CrossesSegment(const geometry::Segment& other) const {
  int64_t a = A * other.first.first + B * other.first.second + C;
  int64_t b = A * other.second.first + B * other.second.second + C;
  return (a * b <= 0);
}

geometry::Line* geometry::Line::Clone() const {
  return new Line(*this);
}

geometry::Vector geometry::Line::Normal() const {
  return Vector(A, B);
}

int64_t geometry::Line::Value(const Point& p) const {
  return B * p.second + C + A * p.first;
}

std::string geometry::Line::ToString() const {
  return geometry::MakeString("Line", A, B, C);
}