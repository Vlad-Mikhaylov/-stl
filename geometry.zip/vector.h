#ifndef GEOMETRY__VECTOR_H_
#define GEOMETRY__VECTOR_H_

#include <utility>
#include <cstdint>
#include <string>

namespace geometry {

struct Vector : std::pair<int64_t, int64_t> {
  Vector(int64_t x, int64_t y) : std::pair<int64_t, int64_t>(x, y) {
  }
  friend Vector &operator+=(Vector &, const Vector &);
  friend Vector &operator-=(Vector &, const Vector &);
  friend Vector &operator*=(Vector &, int64_t);
  friend Vector &operator/=(Vector &, int64_t);

  friend Vector operator+(const Vector &);
  friend Vector operator-(const Vector &);

  friend Vector operator+(const Vector &, const Vector &);
  friend Vector operator-(const Vector &, const Vector &);
  friend Vector operator*(const Vector &, int64_t);
  friend Vector operator/(const Vector &, int64_t);

  friend bool operator==(const Vector &, const Vector &);

  friend int64_t DotProduct(const Vector &, const Vector &);
  friend int64_t VectorProduct(const Vector &, const Vector &);

  std::string ToString() const;
};

}  // namespace geometry

#endif  // GEOMETRY__VECTOR_H_
