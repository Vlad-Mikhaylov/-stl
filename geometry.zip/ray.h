#ifndef GEOMETRY__RAY_H_
#define GEOMETRY__RAY_H_

#include <cstdint>
#include <string>

#include "shape.h"
#include "vector.h"
#include "point.h"

namespace geometry {

struct Ray : public IShape, std::pair<Point, Vector> {

  Ray() = default;
  Ray(const Point& a, const Point& b) : std::pair<Point, Vector>(a, b - a) {
  }
  Ray(const Point& x, const Vector& v) : std::pair<Point, Vector>(x, v) {
  }
  Ray(const Ray& x) : std::pair<Point, Vector>((x.first), (x.second)) {
  }

  Ray& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Ray* Clone() const override;
  
  std::string ToString() const override;

  Ray& operator=(const Ray&);
};

}  // namespace geometry

#endif  // GEOMETRY__RAY_H_
