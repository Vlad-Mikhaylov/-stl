#ifndef GEOMETRY__POINT_H_
#define GEOMETRY__POINT_H_

#include <cstdint>
#include <string>

#include "shape.h"
#include "vector.h"

namespace geometry {

struct Point : public IShape, std::pair<int, int> {
  Point(int x, int y) : std::pair<int, int>(x, y) {
  }

  Vector operator-(const Point& rhs) const {
    return Vector(first - rhs.first, second - rhs.second);
  }

  Point &Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Point *Clone() const override;
  std::string ToString() const override;
};

}  // namespace geometry

#endif  // GEOMETRY__POINT_H_
