#ifndef GEOMETRY__LINE_H_
#define GEOMETRY__LINE_H_

#include <array>

#include "shape.h"
#include "vector.h"
#include "point.h"

namespace geometry {
struct Line : public IShape {
  int64_t A, B, C;
  Line(const Point&, const Point&);
  Line(const int64_t&, const int64_t&, const int64_t&);

  Line& Move(const Vector&) override;
  Line* Clone() const override;

  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Vector Normal() const;
  int64_t Value(const Point&) const;
  
  std::string ToString() const override;
};

}  // namespace geometry

#endif  // GEOMETRY__LINE_H_
