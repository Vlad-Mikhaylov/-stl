#ifndef GEOMETRY__POLYGON_H_
#define GEOMETRY__POLYGON_H_

#include <vector>

#include "shape.h"
#include "point.h"

namespace geometry {

struct Polygon : public IShape, std::vector<Point> {
  explicit Polygon(const std::vector<Point>& points) : std::vector<Point>(points) {
  }
  Polygon& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Polygon* Clone() const override;
  std::string ToString() const override;
};

}  // namespace geometry

#endif  // GEOMETRY__POLYGON_H_
