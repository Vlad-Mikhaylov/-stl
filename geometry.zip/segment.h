#ifndef GEOMETRY__SEGMENT_H_
#define GEOMETRY__SEGMENT_H_

#include <cstdint>
#include <string>

#include "shape.h"
#include "vector.h"
#include "point.h"

namespace geometry {

struct Segment : public IShape, std::pair<Point, Point> {
  Segment(Point a, Point b) : std::pair<Point, Point>(std::move(a), std::move(b)) {
  }

  Segment& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Segment* Clone() const override;
  
  std::string ToString() const override;
};

}  // namespace geometry

#endif  // GEOMETRY__SEGMENT_H_
