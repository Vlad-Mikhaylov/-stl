#ifndef GEOMETRY__CIRCLE_H_
#define GEOMETRY__CIRCLE_H_

#include <vector>
#include "shape.h"
#include "point.h"

namespace geometry {

struct Circle : public IShape, std::pair<Point, int64_t> {

  Circle(const Point &other, int64_t r) : std::pair<Point, int64_t>(other, r) {
  }

  Circle& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool ContainsPoint1(const Point&) const;
  bool CrossesSegment(const Segment&) const override;
  Circle* Clone() const override;
  
  std::string ToString() const override;
};

}  // namespace geometry

#endif  // GEOMETRY__CIRCLE_H_
